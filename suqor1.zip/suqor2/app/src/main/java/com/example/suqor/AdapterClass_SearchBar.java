package com.example.suqor;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.view.LayoutInflaterCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.security.acl.Group;
import java.util.ArrayList;

public class AdapterClass_SearchBar extends RecyclerView.Adapter<AdapterClass_SearchBar.MyViewHolder> {
    ArrayList<Organizations_SearchBar> list;
    public AdapterClass_SearchBar(ArrayList<Organizations_SearchBar> list){
        this.list = list;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.card_holder_searchbar, viewGroup, false);
        return new MyViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        myViewHolder.id.setText(list.get(i).getOrganizationName());
        myViewHolder.desc.setText(list.get(i).getOrganizationLoc() + "  |  " +  list.get(i).getOrganizationTag()
         + "\nWebsite: " + list.get(i).getOrganizationWeb()
        );
    }




    @Override
    public int getItemCount() {
        return list.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView id, desc;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            id = itemView.findViewById(R.id.nameOfTheOrganization);
            desc = itemView.findViewById(R.id.description);
        }
    }
}
