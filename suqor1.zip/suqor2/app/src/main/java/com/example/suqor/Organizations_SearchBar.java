package com.example.suqor;

public class Organizations_SearchBar {
    // names are same as in Firebase
    private String OrganizationName;
    private String OrganizationLoc;
    private String OrganizationTag;
    private String OrganizationWeb;

    public Organizations_SearchBar() {
    }

    public Organizations_SearchBar(String organizationName, String organizationLoc,
                                   String organizationTag, String organizationWeb) {
        OrganizationName = organizationName;
        OrganizationLoc = organizationLoc;
        OrganizationTag = organizationTag;
        OrganizationWeb = organizationWeb;
    }

    public String getOrganizationName() {
        return OrganizationName;
    }

    public void setOrganizationName(String organizationName) {
        OrganizationName = organizationName;
    }

    public String getOrganizationLoc() {
        return OrganizationLoc;
    }

    public void setOrganizationLoc(String organizationLoc) {
        OrganizationLoc = organizationLoc;
    }

    public String getOrganizationTag() {
        return OrganizationTag;
    }

    public void setOrganizationTag(String organizationTag) {
        OrganizationTag = organizationTag;
    }

    public String getOrganizationWeb() {
        return OrganizationWeb;
    }

    public void setOrganizationWeb(String organizationWeb) {
        OrganizationTag = organizationWeb;
    }
}
